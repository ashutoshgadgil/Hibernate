package org.dem.AutoIncrHibernate;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class TestApp {

	public static void main(String[] args) {
		
		SessionFactory factory=new Configuration().configure().addAnnotatedClass(Book.class).buildSessionFactory();
	
		Session session=factory.openSession();
		
		Book b=new Book("PHP");
		//b.setBid(1);
		session.beginTransaction();
		
		session.save(b);
		
		session.getTransaction().commit();
		
		session.close();
	}

}
