package org.dem.HibernateMaven;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Mobile")
public class Mobile {
	@Id
	@Column(name = "model")
	String model;
	
	@Column(name = "brand")
	String brand;
	
	
	public Mobile() {
		
	}
	public Mobile(String model, String brand) {
		super();
		this.model = model;
		this.brand = brand;
	}
	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model = model;
	}
	public String getBrand() {
		return brand;
	}
	public void setBrand(String brand) {
		this.brand = brand;
	}
	
	
}
