package org.dem.HibernateMaven;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class TestApp {

	public static void main(String[] args) {
		Mobile m=new Mobile("G5Plus","Motorola");
		SessionFactory factory=new Configuration().configure().addAnnotatedClass(Mobile.class).buildSessionFactory();
		Session session=factory.openSession();
		
		try {
			
			session.beginTransaction();
			
			session.save(m);
			
			session.getTransaction().commit();
		
		} catch (Exception e) {
			System.out.println(e);
		}
		finally {
			session.close();
		}
		
		
	}

}
