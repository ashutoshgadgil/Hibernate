package org.dem.Inheritance;

import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Permanent")
@DiscriminatorValue("Permanent_emp")
public class Permanent extends Empl{

	
	@Column(name = "address")
	String address;

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public Permanent(String address) {
		
		this.address = address;
	}
	
	
	
}
