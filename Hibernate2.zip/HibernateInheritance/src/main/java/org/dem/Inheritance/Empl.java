package org.dem.Inheritance;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.Table;

@Entity
@Table(name = "Empl")
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
public class Empl {                                      // Base class
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "eid")
	int eid;
	
	@Column(name = "ename")
	String ename;
	
	@Column(name = "dept")
	String dept;
	
	
	public Empl() {
		
	}
	public Empl(String ename, String dept) {
		super();
		this.ename = ename;
		this.dept = dept;
	}
	public String getEname() {
		return ename;
	}
	public void setEname(String ename) {
		this.ename = ename;
	}
	public String getDept() {
		return dept;
	}
	public void setDept(String dept) {
		this.dept = dept;
	}
	public int getEid() {
		return eid;
	}
	public void setEid(int eid) {
		this.eid = eid;
	}

	
}
