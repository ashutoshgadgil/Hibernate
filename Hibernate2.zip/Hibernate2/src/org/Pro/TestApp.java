package org.Pro;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class TestApp {

	public static void main(String[] args) {

		Country c=new Country(2,"England");
		
		// Create Session Factory 
		SessionFactory factory=new Configuration()
				                  .configure()
				                  .addAnnotatedClass(Country.class)
				                  .buildSessionFactory();
		
		// Create session object
		Session session=factory.openSession();
		
		// It makes your Application to perform database transaction / operation
		session.beginTransaction();
		
		// Perform operations in the database (insert/delete/read/update)
		session.save(c);
		
		session.getTransaction().commit();
		
		System.out.println("Data saved...");
		session.close();

	}

}
