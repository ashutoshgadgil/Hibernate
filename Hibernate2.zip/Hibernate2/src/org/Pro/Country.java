package org.Pro;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Country")
public class Country {
	
	@Id
	@Column(name = "country_Code")
	int country_Code;
	
	@Column(name = "country_Name")
	String country_Name;
	
	
	public Country() {

	}


	public Country(int country_Code, String country_Name) {
		super();
		this.country_Code = country_Code;
		this.country_Name = country_Name;
	}


	public int getCountry_Code() {
		return country_Code;
	}


	public void setCountry_Code(int country_Code) {
		this.country_Code = country_Code;
	}


	public String getCountry_Name() {
		return country_Name;
	}


	public void setCountry_Name(String country_Name) {
		this.country_Name = country_Name;
	}
	
	
	
}
